"""Motion filtering helpers."""
