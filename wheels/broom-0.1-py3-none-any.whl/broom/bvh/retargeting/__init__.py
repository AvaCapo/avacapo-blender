"""BVH retargeting helpers."""

from broom.bvh.retargeting.mapping import (
    build_joint_mapping,
    load_joint_mapping,
    map_joints,
    score_joint_match,
)
from broom.bvh.retargeting.retarget import (
    retarget_bvh_file,
    retarget_motion,
)
from broom.bvh.retargeting.root_motion import (
    align_root_to_floor,
    skeleton_scale,
    transfer_root_translation,
)
from broom.bvh.retargeting.rotation_transfer import (
    rotation_channels_by_name,
    transfer_fk_rotations,
)
from broom.bvh.retargeting.schemas import (
    JointMatch,
    MappingResult,
    RetargetResult,
)
from broom.bvh.retargeting.smplx import retarget_bvh_to_smplx

__all__ = (
    "JointMatch",
    "MappingResult",
    "RetargetResult",
    "align_root_to_floor",
    "build_joint_mapping",
    "load_joint_mapping",
    "map_joints",
    "rotation_channels_by_name",
    "retarget_bvh_file",
    "retarget_bvh_to_smplx",
    "retarget_motion",
    "score_joint_match",
    "skeleton_scale",
    "transfer_fk_rotations",
    "transfer_root_translation",
)
