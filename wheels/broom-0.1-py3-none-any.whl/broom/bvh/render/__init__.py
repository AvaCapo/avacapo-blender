"""BVH rendering helpers."""

__all__ = ()
